O L D  O N E (T E S T)

High res model replacement of the Old One (Shub Niggurath) for Dark Places Quake source port engine. 

Model and skins by Tea Monster

Replacement model in MD3 format (named as oldone.mdl)
Skins in non PBR targa format.

Animations: 
1. Old one 1 -70 Original Quake model animations
  - 1 -46 Idle
  - 47 - 70 Death

2. Attack - New animation of the Old One sweep attacking the ground in front of him.

3. Crawl - New animation of the creature crawling forward.


Email: tea(underscore)monster(at)yahoo(dot)com

Model is issued under a Creative Commons Attribution-NonCommercial 3.0 Unported License



